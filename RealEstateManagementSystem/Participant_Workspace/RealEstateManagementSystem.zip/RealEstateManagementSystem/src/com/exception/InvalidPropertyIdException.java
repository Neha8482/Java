package com.exception;

public class InvalidPropertyIdException extends Exception{
	private static final long serialVersionUID = 1L;

	public InvalidPropertyIdException() {
		
	}
}
