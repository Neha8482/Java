package com.beans;

public enum DealType {
	purchase, sales;
}
