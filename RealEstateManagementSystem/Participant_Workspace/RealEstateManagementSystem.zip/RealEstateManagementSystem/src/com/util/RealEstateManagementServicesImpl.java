package com.util;

public class RealEstateManagementServicesImpl implements RealEstateManagementServices{

}
