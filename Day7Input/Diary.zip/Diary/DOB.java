package Diary;

public class DOB {
	
	private int day;
	private String month;
	private int year;
	public DOB(int day, String month, int year) {
		super();
		this.day = day;
		this.month = month;
		this.year = year;
	}
	
	

}
