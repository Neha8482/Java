import java.util.Comparator;

public class MovieComparator implements Comparator<MovieDetails> {

	@Override
	public int compare(MovieDetails o1, MovieDetails o2) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
