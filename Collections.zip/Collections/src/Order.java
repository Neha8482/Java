import java.util.HashMap;
import java.util.Map;

public class Order {

	public static void main(String[] args) {
		Map<Product,Integer> map = new HashMap();
		
		
		
		
		
	}
}
