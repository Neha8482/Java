/*
 * Customer class
	customerId - Integer
	cutomerName - String
	customerAddress - String
	
	order - Set of products - 
	set will hold names of the products
	
	Products class 
	product id
	product name
	cost
 */
public class Customer {

	private Integer customerID;
	private String customerName;
	private String customerAddess;
	
	
	
	
}
